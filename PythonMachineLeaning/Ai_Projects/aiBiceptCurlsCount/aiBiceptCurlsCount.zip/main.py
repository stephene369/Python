import app


def main() :
    app.App()


if __name__ == "__name__" :
    main()
else :
    main()