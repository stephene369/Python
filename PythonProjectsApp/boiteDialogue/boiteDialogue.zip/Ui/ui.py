from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *
import sys
import os
from pathlib import Path
from modules.recentDir import recent

"""from win32api import GetSystemMetrics , GetUserName
WIDTH_ = GetSystemMetrics(0)
HEIGHT_ = GetSystemMetrics(1)
USER = GetUserName()
PATH_ = ''

X = int(WIDTH_/5)
Y = int(HEIGHT_/5)
W = int(WIDTH_-(2*X))
H = int(HEIGHT_-(1.5*Y))"""

X,Y,W,H = 255,155,700,500

IMAGE_SUFFIX = ['.png' , '.jpeg','.jpg','.gif','.bmp','.tiff','.svg','.ico','.webp','.raw',
                '.exif','.psd','.ai','.eps','.xcf','.indd']



class Ui_MainWindow(object) :
    def setupUi(self , MainWindow:QWidget): 
        MainWindow.resize(QSize())
        MainWindow.setGeometry(X,Y,W,H)
        MainWindow.setMinimumSize(QSize(W,H))
        #MainWindow.setMaximumSize(QSize(W,H))
        #MainWindow.setWindowFlag(Qt.FramelessWindowHint)

    
        self.central = QWidget(MainWindow)
        self.VBox0 = QVBoxLayout(MainWindow)
        self.VBox0.addWidget(self.central)

        self.frame0 = QFrame(self.central)
        self.frame1 = QFrame(self.central)
        self.VBox1 = QVBoxLayout(self.central)
        self.VBox1.addWidget(self.frame0)
        self.VBox1.addWidget(self.frame1)

# rfame 0
        self.hBox0 = QHBoxLayout(self.frame0)
        self.hSapce = QSpacerItem(40,20,
                        QSizePolicy.Expanding , QSizePolicy.Minimum)
        self.close = QPushButton(self.frame0)
        self.logo = QLabel(self.frame0)

        self.hBox0.addWidget(self.logo)
        self.hBox0.addSpacerItem(self.hSapce)
        self.hBox0.addWidget(self.close)
        self.close.setIcon(QIcon("icons/close.svg"))
        self.close.setIconSize(QSize(30,30))
        self.close.clicked.connect(lambda: sys.exit() )

## Frame1 
        self.frame1.setSizePolicy(QSizePolicy.Minimum,
                                  QSizePolicy.Expanding) 
        
        self.VBox2 = QVBoxLayout(self.frame1)
        #self.dirBtn = QPushButton(self.frame1)
        #self.anyFile = QPushButton(self.frame1)
        #self.oneFile = QPushButton(self.frame1)
        #self.imageFile = QPushButton(self.frame1)
        
        self.label = QLabel(self.frame1)
        self.charger = QPushButton(self.frame1)
        self.verificaton = QPushButton(self.frame1)
        self.start = QPushButton(self.frame1)

        self.VBox2.addWidget(self.charger,0, Qt.AlignHCenter|Qt.AlignVCenter)
        self.VBox2.addWidget(self.verificaton,0, Qt.AlignHCenter|Qt.AlignVCenter)
        self.VBox2.addWidget(self.start ,0, Qt.AlignHCenter|Qt.AlignVCenter)
        #elf.VBox2.addWidget(self.imageFile)
        self.VBox2.addWidget(self.label)

        self.VBox2.setContentsMargins(0,50,0,50)
        self.VBox2.setSpacing(30)

        self.charger.setText("Chargement de fichier")
        self.verificaton.setText("Verification donnees")
        self.start.setText("Demarrer")

        self.charger.clicked.connect(lambda: self.dialConn("file"))
        self.verificaton.clicked.connect(lambda : self.verify() )

        self.dialog = QFileDialog()
        self.popUp = QMessageBox()
        self.central.setStyleSheet("background-color:rgba(0,0,255,30)")

##
        BUTTON = [self.charger,self.verificaton,self.start]
        font = QFont()
        font.setFamily(u"Yu Gothic UI Light")
        font.setPointSize(26)
        font.setBold(True)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(QFont.Weight(83))
        font.setStrikeOut(False)
        for button in BUTTON : 
            button.setStyleSheet("""border-radius: 20px;""")
            button.setFixedHeight(60)
            button.setFont(font)
            button.setEnabled(False)
        self.charger.setEnabled(True)

        logoFont = QFont()
        font.setFamily(u"Wingdings")
        font.setPointSize(26)
        font.setBold(True)
        font.setItalic(False)
        font.setUnderline(False)
        font.setWeight(QFont.Weight(83))
        font.setStrikeOut(False)

        self.logo.setText("  easy  mark  ")
        self.logo.setFont(logoFont)
        self.logo.setFixedWidth(150)
        self.logo.setFixedHeight(45)

        self.close.setHidden(True)
        

    def dialConn(self , dial:str):
        if dial == 'dossier' :
            self.dialog.setFileMode(QFileDialog.getExistingDirectory())
            self.dialog.exec_()
            print(str(self.dialog.getExistingDirectory( None,"Dossier " , " ")))
            self.label.setText(str(self.dialog.getExistingDirectory( )))

        elif dial=='file' :
            path = recent().read_()
            self.dialog.setFileMode(QFileDialog.FileMode.AnyFile)
       
            self.file_path,_ = self.dialog.getOpenFileNames( None,"fichiers ",path)
            print(self.file_path)
            self.label.setText(str(self.file_path))
            if self.file_path != [] : 
                recent().write_(str(Path(self.file_path[0]).parent)) 
                print("done")
                self.verificaton.setEnabled(True) ; self.start.setEnabled(False)
            else : self.verificaton.setEnabled(False) ; self.start.setEnabled(False)
           

        elif dial=='python' :
            self.dialog.setNameFilter("PYTHON (*.py)")
            self.dialog.setFileMode(QFileDialog.ExistingFiles)
            self.dialog.exec_()

            self.label.setText(str(self.dialog.selectedFiles()))

        elif dial=="image" :
            self.dialog.setFileMode(QFileDialog.FileMode.AnyFile)
            self.dialog.setNameFilter("Images (*.png *.jpg *.jpeg *.gif  *.bmp *.tiff *.svg *.icon *.webp *.raw *.exif *.psd *.ai *.eps *.xcf *.indd)")
            self.dialog.setFileMode(QFileDialog.ExistingFiles)
            self.dialog.exec_()
            self.file_path = self.dialog.selectedFiles()
            self.label.setText(str(self.file_path))
            
            if self.file_path != [] : self.verificaton.setEnabled(True) ; self.start.setEnabled(False)
            else : self.verificaton.setEnabled(False) ; self.start.setEnabled(False)


    def verify(self) :

        # condition pour que le dossier ne contienne que des images
        cond1 = 0

        # recuparation de la liste des fichiers du dossiers
        self.list_file = os.listdir( Path(self.file_path[0]).parent )
        print(self.list_file)
        
        # Liste des fichiers contenu dans le dossiers sans l'extension 
        self.liste_file2 = [ Path(name).stem for name in self.list_file  ]
        
        # Verifier que tous les fichiers sont des images
        liste_extensions = []
        Message = []
        for file in self.list_file :
            extension = Path(file).suffix
            #liste_extensions.append(extension)
            if extension not in IMAGE_SUFFIX:
                cond1 += 1
                print("Le dossier ne doit contenir que des images !")
                # POP up a implementer 

                Message.append("type")
                break

        # on verifie si les fichiers sont bien renommés avec des caractères chiffres
        # (uniquement si tous les fichiers sont des images) 

        if cond1 == 0:
            # on essaie de convertir les noms de fichier en entiers
            # (si la conversion marche, on continue le programme)
            try:
                for j in range(0, len(self.liste_file2)):
                    self.liste_file2[j] = int(self.liste_file2[j])

                # on suppose que la conversion a marché et donc le programme continue

                # on recupere le nombre de fichiers presents dans le dossier
                self.lenList_File2 = len(self.liste_file2)

                # On s'assure que le nom de chaque fichier excepté l'extension est égale a 1 ou 2 ou 3 ou ...

                # on doit ordonner les noms de fichiers de manière croissante 
                # car l'ordre dans la liste ici peut différer à tort de l'ordre dans le dossier

                self.liste_file2.sort()
                print('Liste ordonnée :', self.liste_file2)
                
                # initialiser un compteur de fichiers mal renommés
                self.fichier_mal_renommer = 0

                for i in range(0,self.lenList_File2) :
                    if self.liste_file2[i] != i+1 :
                        self.fichier_mal_renommer+=1

                # si le compteur est > 0 alors il y a des fichiers mal renommés
                if self.fichier_mal_renommer > 0 :
                    print("Les fichiers n'ont pas été renommés dans l'ordre")
                    # Pop up a implement
                    Message.append("name")

                else :
                    print("Données vérifiées")
                    # Pop up à implémenter
                    Message.append("data")
            except:
                # la conversion des noms de fichier en entiers n'a pas marché 
                print("Les fichiers n'ont pas été renommés avec des caractères numériques")
                # popup
                Message.append("ordre")

        set(Message)
        for message in Message:
            if message == 'name' :
                self.popUp.setText("Fichier mal renommer")
                self.popUp.setIcon(QMessageBox.Icon.Information)
                self.popUp.setStandardButtons(QMessageBox.Ok)
                self.popUp.show()
                btn = self.popUp.button(QMessageBox.Ok)
                btn.clicked.connect(self.popUp.accept)
                self.label.setText("Les fichers doivent etre nommé de 1 à n")
            elif message == 'type' :
                self.popUp.setText("Le dossier le doit contenir que des images")
                self.popUp.setIcon(QMessageBox.Icon.Information)
                self.popUp.setStandardButtons(QMessageBox.Ok)
                self.popUp.show()
                btn = self.popUp.button(QMessageBox.Ok)
                self.label.setText("Choisissez un dossier contenant uniquement des images ")
                btn.clicked.connect(self.popUp.accept)
            elif message =='data' :
                self.popUp.setText("Données vérifiées")
                self.popUp.setIcon(QMessageBox.Icon.Information)
                self.popUp.setStandardButtons(QMessageBox.Ok)
                self.popUp.show()
                btn = self.popUp.button(QMessageBox.Ok)
                btn.clicked.connect(self.popUp.accept)    
                self.start.setEnabled(True)        
            elif message == 'ordre' :
                self.popUp.setText("Les fichiers n'ont pas été renommés avec des caractères numériques")
                self.popUp.setIcon(QMessageBox.Icon.Information)
                self.popUp.setStandardButtons(QMessageBox.Ok)
                self.popUp.show()
                btn = self.popUp.button(QMessageBox.Ok)
                self.label.setText("Nommés les fichiers avec des caractères numériques")
                btn.clicked.connect(self.popUp.accept)

