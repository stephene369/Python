import xlrd

def choice_liste(path:str,liste_file2:list) :
	# lecture fichier
	workbook = xlrd.open_workbook(path)

	# on cherche à verifier si le nombre de feuilles est = au nbre de fichiers images 
	# Et si ces feuilles sont renommées dans l'ordre des fichiers images
	# Si ces conditions ne sont pas verifier une exception sera soulever

	#liste_file2 = [1,2,3]
	# obtention de la liste des noms des feuilles

	sheet_names = []
	for sh in workbook.sheets() :
		sheet_names.append(sh.name)

	liste_file2_str = [str(i) for i in liste_file2]
	condition = sheet_names==liste_file2_str
	
	if condition==False :
		
		print("Mauvaise configuration du fichier liste")
		# POPUP a implementer

	else :

		sheet_datas = []

		for i in liste_file2:
			sheet = workbook.sheet_by_index(i-1)
			sheet_datas.append(sheet)
			
		print(sheet_datas) 

		# afficher le nbre de lignes et de colonnes renseignées par feuilles

		print('\nNombre de lignes et de colonnes renseignées par feuilles')

		numFeuille = 1
		for i in sheet_datas:
			print('\n-----Feuille ',numFeuille,'-----')
			print('Rows :',i.nrows)
			print('Cols :',i.ncols)
			numFeuille += 1

		# Recuperer les noms de chaque feuille

		names = []
		numFeuille = 1
		for k in sheet_datas:
			col = k.col_values(0, start_rowx=0, end_rowx=None)
			names.append({numFeuille:col})
			numFeuille += 1

		# afficher les noms sur chaque feuille

		print('\nLes noms sur chaque feuille\n')

		for i in names:
			print(i)

		#except Exception as e :
		# popup a implementer 
		# mauvaise configuratin du fichier liste
		#print(e)


#choice_liste(path=r"C:\Users\steph\Pictures\test\test xlrd\File.xls",liste_file2=[1,2,3,4])