import dill
import cv2 
import numpy as np
import pandas as pd

with open('tools/processing', 'rb') as file:
	processing = dill.load(file)


job = processing.etape3(r"c:\Users\steph\Pictures\test\b - Copie\2.jpg")

job = processing.etape3(r"c:\Users\steph\Pictures\test\b - Copie\2.jpg")
help(processing)

import cv2 

image='tools/1.jpg'
im1 = cv2.imread(image)
copy = im1.copy()



