AVATAR_ICON = r"resource\icons\AvatarIcon.png"


